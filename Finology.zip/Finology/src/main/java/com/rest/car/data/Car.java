package com.rest.car.data;

import java.util.List;

import lombok.Data;


@Data
public class Car {
    private String type;
    private String make;
    private String model;
    private int year;
    
    private List<CarPart> parts;
}

