package com.rest.car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinologyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinologyApplication.class, args);
	}

}
