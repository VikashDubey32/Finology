package com.rest.car.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rest.car.data.Car;
import com.rest.car.data.CarPart;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CarController {

    @GetMapping("/get_car")
    public Car getCar(@RequestParam String car_type) {
        Car car = new Car();
        car.setType(car_type);

        switch (car_type) {
            case "electrical":
                car.setMake("Tesla");
                car.setModel("EV Model");
                car.setYear(2020);
                
                // Define electrical car parts
                List<CarPart> electricalParts = new ArrayList<>();
                electricalParts.add(new CarPart("Battery", "Lithium-ion battery pack"));
                electricalParts.add(new CarPart("Motor", "Electric motor"));           
                
                car.setParts(electricalParts);
                break;

            case "2 wheels":
                car.setMake("Harley-Davidson");
                car.setModel("setter");
                car.setYear(2019);

                // Define 2-wheeler parts
                List<CarPart> twoWheelsParts = new ArrayList<>();
                twoWheelsParts.add(new CarPart("Engine", "V-Twin engine"));
                twoWheelsParts.add(new CarPart("Frame", "Steel frame"));

                car.setParts(twoWheelsParts);
                break;

            case "sport":
                car.setMake("Ferrari");
                car.setModel("420 GTB");
                car.setYear(2022);

                // Define sports car parts              
                List<CarPart> sportsCarParts = new ArrayList<>();
                sportsCarParts.add(new CarPart("Engine", "Twin-turbo V8"));
                sportsCarParts.add(new CarPart("Aerodynamics", "Carbon fiber body"));

                car.setParts(sportsCarParts);
                break;

            default:
                // Handle unknown car types
                return null;
        }
    
        return car;
    }
}
